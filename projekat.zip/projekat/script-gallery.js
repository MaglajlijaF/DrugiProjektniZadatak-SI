const images = document.querySelectorAll('.row img');

images.forEach(img => {
    img.addEventListener('mouseover', () => {
        img.style.transform = 'scale(1.1)';
        img.style.transition = 'transform 0.3s ease';
    });

    img.addEventListener('mouseout', () => {
        img.style.transform = 'scale(1)';
    });

    img.addEventListener('click', () => {
        let message = '';

        if (img.alt === 'Narodno pozorište') {
            message = 'Šaljem Vas na stranicu Narodnog pozorišta.';
        } else if (img.alt === 'Kamerni teatar 55') {
            message = 'Šaljem Vas na stranicu Kamernog teatra 55.';
        } else if (img.alt === 'Pozorište mladih') {
            message = 'Šaljem Vas na stranicu Pozorišta mladih.';
        } else if (img.alt === 'SARTR') {
            message = 'Šaljem Vas na stranicu SARTRa.';
        }

        alert(message);
    });
});
