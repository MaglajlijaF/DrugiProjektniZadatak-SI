
window.addEventListener('load', () => {
    alert("Dobrodošli na stranicu o teatarskoj glumi u Sarajevu!");
});



const showList = document.getElementById('showList');
shows.forEach(show => {
    const li = document.createElement('li');
    li.className = 'list-group-item';
    li.textContent = show;
    showList.appendChild(li);
});
